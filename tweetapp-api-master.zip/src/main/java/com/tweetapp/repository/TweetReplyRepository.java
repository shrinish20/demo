package com.tweetapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.domain.TweetReply;

@Repository
public interface TweetReplyRepository extends CrudRepository<TweetReply, String> {

}

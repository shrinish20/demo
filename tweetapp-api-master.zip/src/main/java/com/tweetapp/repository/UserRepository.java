package com.tweetapp.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.domain.User;

@Repository
public interface UserRepository extends CrudRepository<User, String> {
	boolean existsByEmailId(String emailId);
	boolean existsByLoginId(String loginId);
	User findByLoginId(String loginId);
	List<User> findAll();
}

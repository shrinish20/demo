package com.tweetapp.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.domain.Tweet;

@Repository
public interface TweetRepository extends CrudRepository<Tweet, String> {

	List<Tweet> findByLoginId(String loginId);

}
